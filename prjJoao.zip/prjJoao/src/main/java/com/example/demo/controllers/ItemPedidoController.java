package com.example.demo.controllers;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.ItemPedido;
import com.example.demo.services.ItemPedidoService;

@RestController
@RequestMapping("/itempedidos")
public class ItemPedidoController {
    private final ItemPedidoService itemPedidoService;

    @Autowired
    public ItemPedidoController(ItemPedidoService itemPedidoService) {
        this.itemPedidoService = itemPedidoService;
    }

    @PostMapping
    public ItemPedido createItemPedido(@RequestBody ItemPedido itemPedido) {
        return itemPedidoService.saveItemPedido(itemPedido);
    }

    @GetMapping("/{id}")
    public ItemPedido getItemPedido(@PathVariable BigInteger id) {
        return itemPedidoService.getItemPedidoById(id);
    }

    @GetMapping
    public List<ItemPedido> getAllItemPedidos() {
        return itemPedidoService.getAllItemPedidos();
    }

    @DeleteMapping("/{id}")
    public void deleteItemPedido(@PathVariable BigInteger id) {
    	itemPedidoService.deleteItemPedido(id);
    }
}

