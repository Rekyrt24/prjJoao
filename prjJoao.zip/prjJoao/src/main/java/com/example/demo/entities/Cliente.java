package com.example.demo.entities;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table (name = "cliente") 
public class Cliente {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private BigInteger idCliente;
	
	@Column
	private String cidade;
	
	@Column
	private String email;
	
	@Column
	private String nome;
	
	@Column
	private String telefone;

}
