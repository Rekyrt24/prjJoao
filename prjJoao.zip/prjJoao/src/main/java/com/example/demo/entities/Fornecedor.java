package com.example.demo.entities;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table (name = "fornecedor") 
public class Fornecedor {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private BigInteger idFornecer;
	
	@Column
	private String cnpj;
	
	@Column
	private String email;
	
	@Column
	private String nome;
	
	@Column
	private Double telefone;
	
}
