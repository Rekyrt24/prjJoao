package com.example.demo.entities;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table (name = "itempedido") 
public class ItemPedido {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private BigInteger idItem;
	
	@Column
	private Integer quantidade;
	
	@Column
	private Double valorUnitario;
	
	@OneToOne
	@JoinColumn (name = "pedido_id")
	private Pedido pedido;
	
	@OneToOne
	@JoinColumn (name = "produto_id")
	private Produto produto;
}
