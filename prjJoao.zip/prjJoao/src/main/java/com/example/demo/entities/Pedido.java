package com.example.demo.entities;

import java.math.BigInteger;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table (name = "pedido") 
public class Pedido {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private BigInteger idPedido;
	
	@Column
	private String dataPedido;
	
	@Column
	private Double valorTotal;
	
	@OneToOne
	@JoinColumn (name = "cliente_id")
	private Cliente cliente;
	
	@OneToOne
	@JoinColumn (name = "fornecedor_id")
	private Fornecedor fornecedor;
}
