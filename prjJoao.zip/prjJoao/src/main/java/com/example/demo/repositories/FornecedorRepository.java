package com.example.demo.repositories;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Fornecedor;

public interface FornecedorRepository extends JpaRepository<Fornecedor, BigInteger> {


}