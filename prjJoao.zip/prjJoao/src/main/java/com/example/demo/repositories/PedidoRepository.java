package com.example.demo.repositories;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, BigInteger> {


}
