package com.example.demo.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.ItemPedido;
import com.example.demo.repositories.ItemPedidoRepository;

@Service
public class ItemPedidoService {
    private final ItemPedidoRepository itemPedidoRepository;

    @Autowired
    public ItemPedidoService(ItemPedidoRepository itemPedidoRepository) {
        this.itemPedidoRepository = itemPedidoRepository;
    }

    public ItemPedido saveItemPedido(ItemPedido itemPedido) {
        return itemPedidoRepository.save(itemPedido);
    }

    public ItemPedido getItemPedidoById(BigInteger id) {
        return itemPedidoRepository.findById(id).orElse(null);
    }

    public List<ItemPedido> getAllItemPedidos() {
        return itemPedidoRepository.findAll();
    }

    public void deleteItemPedido(BigInteger id) {
    	itemPedidoRepository.deleteById(id);
    }
}
